# AnakhasBookStore.Book

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **Number** |  | 
**title** | **String** |  | 
**author** | **String** |  | [optional] 
**publisher** | **String** |  | [optional] 
**ISBN** | **String** |  | [optional] 
**pubdate** | **String** |  | [optional] 
**nopg** | **Number** |  | [optional] 
**genre** | **String** |  | [optional] 
