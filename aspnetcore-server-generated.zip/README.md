# IO.Swagger - ASP.NET Core 2.0 Server

Hey there!<br>   Looking for some interesting books to read?<br>   Then this is the right place for u.   Have a good read!   

## Run

Linux/OS X:

```
sh build.sh
```

Windows:

```
build.bat
```

## Run in Docker

```
cd src/IO.Swagger
docker build -t io.swagger .
docker run -p 5000:5000 io.swagger
```
